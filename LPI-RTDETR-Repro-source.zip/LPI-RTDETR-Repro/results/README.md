# Saved results

This directory contains compact, immutable outputs from the reported run. It
does not contain checkpoints or ExDark images.

- `official`: validation/test metrics, complexity measurements, and the fixed
  protocol.
- `training_curves`: one JSON record per epoch for each variant.
- `analysis`: brightness strata, confusion matrices, paired bootstrap output,
  and plot source tables.

Historical experiment keys are preserved in these files:

| archived key | public name |
|---|---|
| `baseline` | RT-DETRv2-R18 |
| `cascade` | Nano pixel cascade (E1) |
| `prior` | LPI-RTDETR (E2) |
| `gated` | gated extension (E3) |
| `v2` | regularized extension (E4) |

New runs use `lpi` and `regularized` instead of `prior` and `v2`.

