"""
Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
https://github.com/facebookresearch/detr/blob/main/engine.py

Copyright(c) 2023 lyuwenyu. All Rights Reserved.
"""

import sys
import math
import json
import time
from pathlib import Path
from typing import Iterable

import torch
import torch.amp 
from torch.utils.tensorboard import SummaryWriter
from torch.cuda.amp.grad_scaler import GradScaler

from ..optim import ModelEMA, Warmup
from ..data import CocoEvaluator
from ..misc import MetricLogger, SmoothedValue, dist_utils


def train_one_epoch(model: torch.nn.Module, criterion: torch.nn.Module,
                    data_loader: Iterable, optimizer: torch.optim.Optimizer,
                    device: torch.device, epoch: int, max_norm: float = 0, **kwargs):
    model.train()
    criterion.train()
    metric_logger = MetricLogger(delimiter="  ")
    metric_logger.add_meter('lr', SmoothedValue(window_size=1, fmt='{value:.6f}'))
    header = 'Epoch: [{}]'.format(epoch)
    
    print_freq = kwargs.get('print_freq', 10)
    writer :SummaryWriter = kwargs.get('writer', None)

    ema :ModelEMA = kwargs.get('ema', None)
    scaler :GradScaler = kwargs.get('scaler', None)
    lr_warmup_scheduler :Warmup = kwargs.get('lr_warmup_scheduler', None)
    step_log_path = kwargs.get('step_log_path', None)
    step_log = None
    if step_log_path and dist_utils.is_main_process():
        step_log_path = Path(step_log_path)
        step_log_path.parent.mkdir(parents=True, exist_ok=True)
        step_log = step_log_path.open('a', encoding='utf-8', buffering=1)

    total_steps = len(data_loader)
    for i, (samples, targets) in enumerate(data_loader):
        if torch.cuda.is_available() and i == 0:
            torch.cuda.reset_peak_memory_stats()
        step_start = time.perf_counter()
        samples = samples.to(device)
        targets = [{k: v.to(device) for k, v in t.items()} for t in targets]
        global_step = epoch * len(data_loader) + i
        metas = dict(epoch=epoch, step=i, global_step=global_step)

        if scaler is not None:
            with torch.autocast(device_type=str(device), cache_enabled=True):
                outputs = model(samples, targets=targets)
            
            with torch.autocast(device_type=str(device), enabled=False):
                loss_dict = criterion(outputs, targets, **metas)

            loss = sum(loss_dict.values())
            scaler.scale(loss).backward()
            
            grad_norm = None
            if max_norm > 0:
                scaler.unscale_(optimizer)
                grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm)

            scaler.step(optimizer)
            scaler.update()
            optimizer.zero_grad()

        else:
            outputs = model(samples, targets=targets)
            loss_dict = criterion(outputs, targets, **metas)
            
            loss : torch.Tensor = sum(loss_dict.values())
            optimizer.zero_grad()
            loss.backward()
            
            grad_norm = None
            if max_norm > 0:
                grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm)

            optimizer.step()
        
        # ema 
        if ema is not None:
            ema.update(model)

        if lr_warmup_scheduler is not None:
            lr_warmup_scheduler.step()

        loss_dict_reduced = dist_utils.reduce_dict(loss_dict)
        loss_value = sum(loss_dict_reduced.values())

        if not math.isfinite(loss_value):
            print("Loss is {}, stopping training".format(loss_value))
            print(loss_dict_reduced)
            if step_log is not None:
                step_log.close()
            raise FloatingPointError(f"Non-finite loss at epoch={epoch}, step={i}: {loss_dict_reduced}")

        metric_logger.update(loss=loss_value, **loss_dict_reduced)
        metric_logger.update(lr=optimizer.param_groups[0]["lr"])

        if dist_utils.is_main_process() and (i % print_freq == 0 or i + 1 == total_steps):
            key_terms = []
            for key in ("loss_vfl", "loss_bbox", "loss_giou", "loss_fusion_budget", "loss_gate_tv"):
                if key in loss_dict_reduced:
                    key_terms.append(f"{key.removeprefix('loss_')}={float(loss_dict_reduced[key]):.4f}")
            gpu = torch.cuda.max_memory_allocated() / 2**30 if torch.cuda.is_available() else 0.
            print(f"[Train] epoch={epoch + 1} step={i + 1}/{total_steps} "
                  f"loss={float(loss_value):.4f} {' '.join(key_terms)} "
                  f"lr={optimizer.param_groups[0]['lr']:.2e} gpu_peak={gpu:.2f}GB")

        if step_log is not None:
            module = dist_utils.de_parallel(model)
            diagnostics = module.diagnostics() if hasattr(module, 'diagnostics') else {}
            row = {
                'epoch': epoch, 'step_in_epoch': i, 'global_step': global_step,
                'batch_size': int(samples.shape[0]), 'loss_total': float(loss_value),
                'step_time_ms': 1000. * (time.perf_counter() - step_start),
                'throughput_images_s': float(samples.shape[0]) / max(time.perf_counter() - step_start, 1e-9),
                'lr_groups': [float(pg['lr']) for pg in optimizer.param_groups],
                'grad_norm': float(grad_norm) if grad_norm is not None else None,
                'gpu_allocated_mb': float(torch.cuda.memory_allocated() / 2**20) if torch.cuda.is_available() else 0.,
                'gpu_reserved_mb': float(torch.cuda.memory_reserved() / 2**20) if torch.cuda.is_available() else 0.,
                'gpu_peak_allocated_mb': float(torch.cuda.max_memory_allocated() / 2**20) if torch.cuda.is_available() else 0.,
                **{k: float(v) for k, v in loss_dict_reduced.items()}, **diagnostics,
            }
            step_log.write(json.dumps(row, ensure_ascii=False) + '\n')

        if writer and dist_utils.is_main_process():
            writer.add_scalar('Loss/total', loss_value.item(), global_step)
            for j, pg in enumerate(optimizer.param_groups):
                writer.add_scalar(f'Lr/pg_{j}', pg['lr'], global_step)
            for k, v in loss_dict_reduced.items():
                writer.add_scalar(f'Loss/{k}', v.item(), global_step)
                
    if step_log is not None:
        step_log.close()
    # gather the stats from all processes
    metric_logger.synchronize_between_processes()
    compact = {key: metric_logger.meters[key].global_avg for key in
               ("loss", "loss_vfl", "loss_bbox", "loss_giou") if key in metric_logger.meters}
    print("[Train epoch average]", " ".join(f"{k}={v:.4f}" for k, v in compact.items()))
    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}


@torch.no_grad()
def evaluate(model: torch.nn.Module, criterion: torch.nn.Module, postprocessor, data_loader, coco_evaluator: CocoEvaluator, device):
    model.eval()
    criterion.eval()
    coco_evaluator.cleanup()
    iou_types = coco_evaluator.iou_types

    metric_logger = MetricLogger(delimiter="  ")
    header = 'Test:'
    
    prediction_path = getattr(coco_evaluator, "prediction_path", None)
    exported_predictions = []
    for samples, targets in metric_logger.log_every(data_loader, 10, header):
        samples = samples.to(device)
        targets = [{k: v.to(device) for k, v in t.items()} for t in targets]

        outputs = model(samples)

        # TODO (lyuwenyu), fix dataset converted using `convert_to_coco_api`?
        orig_target_sizes = torch.stack([t["orig_size"] for t in targets], dim=0)
        
        results = postprocessor(outputs, orig_target_sizes)

        # if 'segm' in postprocessor.keys():
        #     target_sizes = torch.stack([t["size"] for t in targets], dim=0)
        #     results = postprocessor['segm'](results, outputs, orig_target_sizes, target_sizes)

        res = {target['image_id'].item(): output for target, output in zip(targets, results)}
        if prediction_path and dist_utils.is_main_process():
            for image_id, output in res.items():
                boxes = output["boxes"].detach().cpu()
                scores = output["scores"].detach().cpu().tolist()
                labels = output["labels"].detach().cpu().tolist()
                boxes[:, 2:] -= boxes[:, :2]
                for box, score, label in zip(boxes.tolist(), scores, labels):
                    exported_predictions.append({"image_id": int(image_id), "category_id": int(label),
                                                 "bbox": [float(x) for x in box], "score": float(score)})
        if coco_evaluator is not None:
            coco_evaluator.update(res)

    # gather the stats from all processes
    metric_logger.synchronize_between_processes()
    print("Averaged stats:", metric_logger)
    if coco_evaluator is not None:
        coco_evaluator.synchronize_between_processes()

    # accumulate predictions from all images
    if coco_evaluator is not None:
        coco_evaluator.accumulate()
        coco_evaluator.summarize()
    if prediction_path and dist_utils.is_main_process():
        prediction_path = Path(prediction_path)
        prediction_path.parent.mkdir(parents=True, exist_ok=True)
        prediction_path.write_text(json.dumps(exported_predictions), encoding="utf-8")

    stats = {}
    # stats = {k: meter.global_avg for k, meter in metric_logger.meters.items()}
    if coco_evaluator is not None:
        if 'bbox' in iou_types:
            stats['coco_eval_bbox'] = coco_evaluator.coco_eval['bbox'].stats.tolist()
        if 'segm' in iou_types:
            stats['coco_eval_masks'] = coco_evaluator.coco_eval['segm'].stats.tolist()
            
    return stats, coco_evaluator



