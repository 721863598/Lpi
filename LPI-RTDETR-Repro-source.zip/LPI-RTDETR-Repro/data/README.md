# ExDark data

The repository includes only the fixed COCO-format annotations. Obtain the
images from the official ExDark distribution and keep the original category
folders and filenames.

```text
images/
├── Bicycle/
├── Boat/
├── Bottle/
└── ...
```

Validate the dataset before training:

```bash
python tools/prepare_data.py --images /path/to/images
```

The annotations define 3000 training, 1800 validation, and 2563 test images.
The split files must not be regenerated if the reported numbers are being
reproduced.

