"""Multinex-Nano loader and COCO checkpoint transfer helpers."""
import importlib.util
from pathlib import Path
import torch

ROOT = Path(__file__).resolve().parent


def make_nano():
    arch = ROOT / "third_party/multinex/MultinexNano_arch.py"
    weight = ROOT / "assets/Multinex-Nano_LOL-v2-real.pth"
    spec = importlib.util.spec_from_file_location("official_multinex_nano", arch)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    model = module.MultinexNano(
        base_channels=3, width_mult=1., target_params=None, use_depthwise=True,
        act="ReLU", reduction_ratio=3, per_illum_proj=False, per_chroma_proj=False,
        illum_mid=1, chroma_mid=1, luma_head_act=None, chroma_head_act=None, eps=1e-9,
        illum_flags=dict(mean=False, rec709=True, vmax=True, lightness=True, ycgco=False, l2norm=True),
        chroma_flags=dict(yuv_uv=False, ycbcr_cbcr=True, opponent=False, chroma_rg=True, hsv_s=True))
    state = torch.load(weight, map_location="cpu")
    for key in ("state_dict", "params_ema", "params", "model"):
        if isinstance(state, dict) and key in state:
            state = state[key]; break
    model.load_state_dict({k.removeprefix("module."): v for k, v in state.items()}, strict=True)
    return model.eval().requires_grad_(False)


def load_matching(model, checkpoint):
    saved = torch.load(checkpoint, map_location="cpu")
    state = saved["ema"]["module"] if "ema" in saved else saved.get("model", saved)
    current = model.state_dict()
    matched = {k:v for k,v in state.items() if k in current and current[k].shape == v.shape}
    missing, unexpected = model.load_state_dict(matched, strict=False)
    return {"loaded":len(matched), "source":len(state), "missing":list(missing), "unexpected":list(unexpected)}


def initialize_coco(model, checkpoint):
    info = load_matching(model, checkpoint)
    allowed = ("denoising_class_embed", "enc_score_head", "dec_score_head")
    bad = [k for k in info["missing"] if not any(name in k for name in allowed)]
    if bad:
        raise RuntimeError(f"Unexpected missing detector tensors: {bad}")
    return info

