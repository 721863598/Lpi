# Release assets

The two compact inference checkpoints in this local directory are ready to be
published as GitHub Release assets. They are ignored by Git and will not be
included by `git add .`.

Files:

- `rtdetrv2_exdark_baseline_best.pth`
- `lpi_rtdetr_e2_best.pth`
- `SHA256SUMS.txt`

After pushing the source repository, a GitHub CLI upload can be performed with:

```bash
gh release create v1.0.0 release_assets/*.pth release_assets/SHA256SUMS.txt \
  --title "LPI-RTDETR ExDark checkpoints"
```

