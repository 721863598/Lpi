# Academic evaluation protocol

## Directly comparable primary table

- Dataset: official ExDark split included in `data/coco`.
- Classes: all 12 official categories.
- Train/validation/test: 3000/1800/2563 images.
- Input: 640x640.
- Selection: validation AP only.
- Final evaluation: official test, once after checkpoint selection.
- Inference: one model, one scale, no TTA.
- Primary metric: COCO AP@[0.50:0.95].
- Secondary metrics: AP50, AP75, APS, APM, APL, AR1, AR10, AR100, ARS, ARM, ARL.
- Per-category metrics: AP, AP50, AP75 and AR100.

## Efficiency table

- Total parameter count and state-dict size.
- Conv/Linear MACs and transparent approximate FLOPs (=2x MACs). Custom deformable-attention operations may not be included, so label this column exactly as generated.
- Batch-1, 640x640, model-only CUDA latency: mean, median and p90.
- FPS is 1000 / mean latency.
- FP32 and AMP FP16 are reported separately.
- Warmup and measured iteration counts are saved with the hardware/software manifest.
- Do not directly rank FPS copied from papers using different GPUs, batch sizes or preprocessing.

## Cross-protocol citations

Literature values in `references/` are context only. Keep their class count, split,
training data, resolution, TTA and source columns. Never bold them as if they were
evaluated under this package's protocol.

Threshold-dependent precision/recall/F1 are not primary COCO metrics. PSNR and
SSIM are excluded because ExDark does not provide paired normal-light targets.
