"""RT-DETRv2 variants used in the ExDark experiments."""
from __future__ import annotations

import sys
from pathlib import Path
import torch
import torch.nn.functional as F
from torch import nn

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "third_party/rtdetrv2"))

from weights import make_nano
from src.zoo.rtdetr.rtdetr import RTDETR


VARIANTS = ("baseline", "cascade", "lpi", "gated", "regularized")
DISPLAY_NAMES = {
    "baseline": "RT-DETRv2-R18",
    "cascade": "Nano + RT-DETRv2",
    "lpi": "LPI-RTDETR (E2)",
    "gated": "Gated extension (E3)",
    "regularized": "Regularized extension (E4)",
}


def luma(x: torch.Tensor) -> torch.Tensor:
    return .299 * x[:, 0:1] + .587 * x[:, 1:2] + .114 * x[:, 2:3]


class PixelCascadeRTDETR(RTDETR):
    """Naive enhancement-before-detection negative control."""

    def __init__(self, detector):
        super().__init__(detector.backbone, detector.encoder, detector.decoder)
        self.nano = make_nano().requires_grad_(True)
        # Zero means the branch starts from the raw image.  The bounded blend
        # prevents an unstable enhancer from replacing the detector input.
        self.blend_logit = nn.Parameter(torch.zeros(()))

    @property
    def blend(self):
        return .5 * torch.tanh(self.blend_logit)

    def forward(self, x, targets=None):
        enhanced = self.nano(x.float()).to(x.dtype)
        detector_input = (x + self.blend * (enhanced - x)).clamp(0, 1)
        features = self.backbone(detector_input)
        return self.decoder(self.encoder(features), targets)

    def diagnostics(self):
        return {"nano_pixel_blend": float(self.blend.detach())}


class PriorFusionBlock(nn.Module):
    def __init__(self, channels, cue_channels, hidden=16, max_scale=.05,
                 budget=.02, gated=False):
        super().__init__()
        self.max_scale = float(max_scale)
        self.budget = float(budget)
        self.gated = bool(gated)
        self.adapter = nn.Sequential(
            nn.Conv2d(cue_channels, hidden, 3, padding=1),
            nn.SiLU(inplace=True),
            nn.Conv2d(hidden, channels, 1),
        )
        self.scale_logit = nn.Parameter(torch.zeros(()))
        self.channel_logit = nn.Parameter(torch.zeros(1, channels, 1, 1))
        if gated:
            self.gate_residual = nn.Sequential(
                nn.Conv2d(4, 8, 3, padding=1), nn.SiLU(inplace=True),
                nn.Conv2d(8, 1, 1), nn.Tanh())
            nn.init.zeros_(self.gate_residual[2].weight)
            nn.init.zeros_(self.gate_residual[2].bias)

    @property
    def scale(self):
        return self.max_scale * torch.tanh(self.scale_logit)

    def forward(self, raw, cues):
        cues = F.interpolate(cues, size=raw.shape[-2:], mode="bilinear",
                             align_corners=False)
        dy, darkness, edge, contrast = cues.split(1, dim=1)
        if self.gated:
            analytic = darkness.square() * (1. - .5 * edge)
            gate = (analytic + .25 * self.gate_residual(cues)).clamp(0, 1)
            adapter_input = torch.cat((dy, darkness, contrast), 1)
        else:
            gate = torch.ones_like(darkness)
            adapter_input = torch.cat((dy, darkness), 1)
        residual = self.adapter(adapter_input)
        channel = 1. + .25 * torch.tanh(self.channel_logit)
        injection = self.scale * gate * channel * residual
        ratio = injection.abs().mean() / raw.detach().abs().mean().clamp_min(1e-6)
        budget_loss = F.relu(ratio - self.budget).square()
        gate_tv = ((gate[..., 1:, :] - gate[..., :-1, :]).abs().mean() +
                   (gate[..., :, 1:] - gate[..., :, :-1]).abs().mean())
        return raw + injection, budget_loss, gate_tv, gate, ratio, injection


class FeaturePriorRTDETR(RTDETR):
    """Feature-level luminance-prior injection."""

    def __init__(self, detector, variant="lpi", channels=(128, 256, 512)):
        if variant not in ("lpi", "gated", "regularized"):
            raise ValueError(f"unsupported feature variant: {variant}")
        super().__init__(detector.backbone, detector.encoder, detector.decoder)
        self.variant = variant
        self.nano = make_nano().requires_grad_(True)
        gated = variant in ("gated", "regularized")
        cue_channels = 3 if gated else 2
        self.prior_fusion = nn.ModuleList([
            PriorFusionBlock(c, cue_channels, gated=gated) for c in channels
        ])
        self._diagnostics = {}
        self._visual = None
        self.capture_visual = False

    def prior_cues(self, x):
        # FP32 here avoids the NaNs observed in early low-light supervision.
        with torch.autocast(device_type=x.device.type, enabled=False):
            low = F.max_pool2d(x.float(), 3, 4, ceil_mode=True)
            nano = self.nano(low)
            dy = luma(nano - low)
            yl = luma(low)
            darkness = ((.60 - yl) / .60).clamp(0, 1)
            gx = F.pad((yl[:, :, :, 1:] - yl[:, :, :, :-1]).abs(), (0, 1, 0, 0))
            gy = F.pad((yl[:, :, 1:, :] - yl[:, :, :-1, :]).abs(), (0, 0, 0, 1))
            edge = (gx + gy).clamp(0, 1)
            contrast = (yl - F.avg_pool2d(yl, 5, 1, 2)).abs().clamp(0, 1)
            return torch.cat((dy, darkness, edge, contrast), 1)

    def fused_backbone(self, x):
        raw = self.backbone(x)
        cues = self.prior_cues(x)
        fused, budgets, tvs, gates, gate_stds, ratios, injections = [], [], [], [], [], [], []
        for feature, block in zip(raw, self.prior_fusion):
            value, budget, tv, gate, ratio, injection = block(feature, cues)
            fused.append(value); budgets.append(budget); tvs.append(tv)
            gates.append(gate.detach().mean()); gate_stds.append(gate.detach().std())
            ratios.append(ratio.detach()); injections.append(injection.detach())
        scales = torch.stack([block.scale.detach() for block in self.prior_fusion])
        self._diagnostics = {
            "scales": scales, "ratios": torch.stack(ratios),
            "gate_means": torch.stack(gates), "gate_stds": torch.stack(gate_stds),
        }
        # CPU copies are deliberately disabled during training and normal
        # evaluation; the qualitative exporter opts in for selected images.
        if self.capture_visual:
            self._visual = {
                "cues": cues[:1].detach().float().cpu(),
                "gates": [torch.ones((1, 1, *f.shape[-2:]), dtype=torch.float32)
                          for f in raw] if self.variant == "lpi" else [],
                "injection_magnitude": [z[:1].abs().mean(1, keepdim=True).float().cpu() for z in injections],
            }
        if self.capture_visual and self.variant != "lpi":
            # Recompute exact learned gates only for the retained first sample.
            self._visual["gates"] = []
            for feature, block in zip(raw, self.prior_fusion):
                resized = F.interpolate(cues[:1], size=feature.shape[-2:], mode="bilinear", align_corners=False)
                dy, darkness, edge, contrast = resized.split(1, 1)
                analytic = darkness.square() * (1. - .5 * edge)
                self._visual["gates"].append((analytic + .25 * block.gate_residual(resized)).clamp(0, 1).detach().float().cpu())
        return fused, {
            "feature_budget": torch.stack(budgets).mean(),
            "gate_tv": torch.stack(tvs).mean(),
        }

    def forward(self, x, targets=None):
        features, joint = self.fused_backbone(x)
        out = self.decoder(self.encoder(features), targets)
        out["_fusion_joint"] = joint
        return out

    def diagnostics(self):
        if not self._diagnostics:
            return {}
        result = {}
        for index, level in enumerate(("p3", "p4", "p5")):
            result[f"fusion_scale_{level}"] = float(self._diagnostics["scales"][index])
            result[f"injection_ratio_{level}"] = float(self._diagnostics["ratios"][index])
            result[f"gate_mean_{level}"] = float(self._diagnostics["gate_means"][index])
            result[f"gate_std_{level}"] = float(self._diagnostics["gate_stds"][index])
        return result


class JointCriterion(nn.Module):
    def __init__(self, detection, variant, budget_weight=10., gate_tv_weight=.02):
        super().__init__()
        self.detection = detection
        self.variant = variant
        self.budget_weight = float(budget_weight)
        self.gate_tv_weight = float(gate_tv_weight)

    def forward(self, outputs, targets, **kwargs):
        joint = outputs.get("_fusion_joint")
        detection_outputs = {k: v for k, v in outputs.items() if k != "_fusion_joint"}
        losses = self.detection(detection_outputs, targets, **kwargs)
        if joint is not None:
            weight_budget = self.budget_weight if self.variant == "regularized" else 0.
            weight_tv = self.gate_tv_weight if self.variant == "regularized" else 0.
            losses["loss_fusion_budget"] = joint["feature_budget"] * weight_budget
            losses["loss_gate_tv"] = joint["gate_tv"] * weight_tv
        return losses


def build_model(detector, criterion, variant):
    if variant == "baseline":
        return detector, criterion
    if variant == "cascade":
        return PixelCascadeRTDETR(detector), criterion
    model = FeaturePriorRTDETR(detector, variant)
    return model, JointCriterion(criterion, variant)
