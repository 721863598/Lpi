# Model assets

Run `python tools/download_weights.py` to obtain
`rtdetrv2_r18_coco.pth`. Expected SHA256:

```text
2ace52184b620204004509b72752ac7bfe64aadfa7fc1d076b18df8ab5a5c77e
```

`Multinex-Nano_LOL-v2-real.pth` is included because it is small. Its SHA256 is:

```text
444533ea24ce2a65266f314b5a6bcc0d52e01cf9fe962b292140d130739c5155
```

