import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_fixed_split_counts():
    expected = {"train": 3000, "val": 1800, "test": 2563}
    for split, count in expected.items():
        data = json.loads((ROOT / f"data/annotations/{split}.json").read_text(encoding="utf-8"))
        assert len(data["images"]) == count
        assert len(data["categories"]) == 12


def test_split_filenames_are_disjoint():
    sets = []
    for split in ("train", "val", "test"):
        data = json.loads((ROOT / f"data/annotations/{split}.json").read_text(encoding="utf-8"))
        sets.append({row["file_name"].replace("\\", "/").lower() for row in data["images"]})
    assert sets[0].isdisjoint(sets[1])
    assert sets[0].isdisjoint(sets[2])
    assert sets[1].isdisjoint(sets[2])

