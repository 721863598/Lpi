"""Train and evaluate LPI-RTDETR on the fixed ExDark split."""
from __future__ import annotations

import argparse
import gc
import importlib.util
import json
import os
import sys
import traceback
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
sys.path.insert(0, str(ROOT / "third_party/rtdetrv2"))

from src.misc import dist_utils
from analysis import run_all_analyses
from models import DISPLAY_NAMES, VARIANTS, build_model
from pipeline import (COCO_WEIGHT, benchmark, build_cfg, environment_manifest,
                         final_evaluate, initialize_coco, resolve_images,
                         train_stage, validate_dataset)


def parse_args():
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--images", type=Path,
        required=True, help="directory containing the ExDark category folders")
    parser.add_argument("--annotations", type=Path, default=ROOT / "data/annotations")
    parser.add_argument("--output", type=Path, default=ROOT / "runs/exdark")
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--val-batch-size", type=int, default=8)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--prefetch-factor", type=int, default=2)
    parser.add_argument("--cpu-threads", type=int, default=8)
    parser.add_argument("--common-epochs", type=int, default=30)
    parser.add_argument("--branch-epochs", type=int, default=80)
    parser.add_argument("--seed", type=int, default=2026)
    parser.add_argument("--branch-seed", type=int, default=2027)
    parser.add_argument("--bootstrap-samples", type=int, default=200)
    parser.add_argument("--benchmark-warmup", type=int, default=50)
    parser.add_argument("--benchmark-iters", type=int, default=200)
    parser.add_argument("--skip-analysis", action="store_true")
    parser.add_argument("--skip-benchmark", action="store_true")
    parser.add_argument("--report-only", action="store_true")
    parser.add_argument("--dry-run", action="store_true",
                        help="perform full data/model/backward smoke test, then stop")
    parser.add_argument("--force-eval", action="store_true")
    parser.add_argument("--force-benchmark", action="store_true")
    return parser.parse_args()


def write_locked_json(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        old = json.loads(path.read_text(encoding="utf-8"))
        if old != data:
            raise RuntimeError(f"Protocol mismatch at {path}. Use a new --output directory.")
    else:
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def release_cuda():
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.synchronize(); torch.cuda.empty_cache(); torch.cuda.reset_peak_memory_stats()


def smoke_test(args, paths):
    marker = args.output / "preflight_pass.json"
    if marker.exists():
        print("[Preflight] cached PASS"); return
    print("\n[Preflight] real ExDark batch + forward + all losses + backward")
    rows = []
    for variant in VARIANTS:
        cfg = build_cfg(1, args.output / "_preflight" / variant, paths["images"],
                        paths["train"], paths["val"], 2, 2, 0, 2)
        detector = cfg.model
        load_info = initialize_coco(detector, COCO_WEIGHT)
        model, criterion = build_model(detector, cfg.criterion, variant)
        model = model.cuda().train(); criterion = criterion.cuda().train()
        samples, targets = next(iter(cfg.train_dataloader))
        samples = samples.cuda()
        targets = [{k: v.cuda() for k, v in target.items()} for target in targets]
        with torch.autocast("cuda", dtype=torch.float16):
            outputs = model(samples, targets=targets)
        with torch.autocast("cuda", enabled=False):
            losses = criterion(outputs, targets, epoch=0, step=0, global_step=0)
            total = sum(losses.values())
        if not torch.isfinite(total):
            raise FloatingPointError(f"{variant} preflight non-finite loss: {losses}")
        total.backward()
        if not any(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters() if p.requires_grad):
            raise FloatingPointError(f"{variant} produced no finite gradients")
        with torch.inference_mode():
            model.eval(); prediction = model(samples[:1])
        row = {"variant": variant, "display_name": DISPLAY_NAMES[variant],
               "loss": float(total.detach()), "loaded_coco_tensors": load_info["loaded"],
               "logits_shape": list(prediction["pred_logits"].shape),
               "boxes_shape": list(prediction["pred_boxes"].shape),
               "parameters": sum(p.numel() for p in model.parameters()),
               "trainable_parameters": sum(p.numel() for p in model.parameters() if p.requires_grad)}
        rows.append(row)
        print(f"[Preflight:{variant:<8}] loss={row['loss']:.4f} "
              f"params={row['parameters']:,} output={row['logits_shape']}")
        del prediction, total, losses, outputs, targets, samples, model, criterion, detector, cfg
        release_cuda()
    marker.write_text(json.dumps({"status": "PASS", "variants": rows}, indent=2), encoding="utf-8")
    print("[Preflight PASS] all five variants completed real-data backward")


def main():
    args = parse_args()
    args.output = args.output.resolve(); annotations = args.annotations.resolve()
    numeric = (args.batch_size, args.val_batch_size, args.common_epochs, args.branch_epochs,
               args.cpu_threads, args.bootstrap_samples)
    if any(x < 1 for x in numeric) or args.workers < 0 or args.prefetch_factor < 1:
        raise ValueError("batch/epoch/thread/bootstrap values must be positive; workers may be zero")
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU is required for this final experiment")
    required = ("pandas", "matplotlib", "PIL", "pycocotools", "tensorboard", "tabulate")
    missing = [name for name in required if importlib.util.find_spec(name) is None]
    if missing:
        raise RuntimeError(f"Missing dependencies {missing}; run: pip install -r requirements.txt")

    torch.set_num_threads(args.cpu_threads)
    torch.backends.cudnn.benchmark = True
    dist_utils.setup_distributed(seed=args.seed)
    images = resolve_images(None, args.images.resolve())
    dataset = validate_dataset(images, annotations)
    paths = {"images": images, **{split: annotations / f"{split}.json"
             for split in ("train", "val", "test")}}
    args.output.mkdir(parents=True, exist_ok=True)
    protocol = {
        "protocol_version": "2.0-final-locked",
        "dataset": "ExDark fixed COCO-format split bundled with this experiment",
        "split_counts": {"train": 3000, "val": 1800, "test": 2563},
        "classes": 12, "input_size": [640, 640],
        "common_epochs": args.common_epochs, "branch_epochs": args.branch_epochs,
        "batch_size": args.batch_size, "val_batch_size": args.val_batch_size,
        "workers": args.workers, "seed": args.seed, "branch_seed": args.branch_seed,
        "variants": list(VARIANTS), "variant_names": DISPLAY_NAMES,
        "optimizer": "AdamW with variant-specific parameter-group learning rates",
        "training_augmentation": "official RT-DETRv2 geometric + photometric recipe; identical across rows",
        "amp": "FP16", "ema": True, "single_scale_test": True, "tta": False,
        "primary_metric": "COCO AP@[0.50:0.95]", "literature_bridge_metric": "AP50",
        "checkpoint_selection": "highest validation COCO AP",
        "test_policy": "one final evaluation per selected model; no test-set tuning",
        "bootstrap": {"paired_unit": "image", "replicates": args.bootstrap_samples,
                      "seed": args.branch_seed},
    }
    write_locked_json(args.output / "protocol.json", protocol)
    write_locked_json(args.output / "dataset_manifest.json", dataset)
    (args.output / "environment.json").write_text(
        json.dumps(environment_manifest(args, dataset), indent=2), encoding="utf-8")
    print(f"[Dataset PASS] {images}")
    print("[Protocol] train/val/test=3000/1800/2563 | 12 classes | 640 | no TTA")
    smoke_test(args, paths)
    if args.dry_run:
        print("[DryRun COMPLETE] no formal training was started"); return
    if args.report_only:
        from report import main as build_report
        build_report(args.output); return

    common = train_stage("common30", "common", args.common_epochs,
                         args.output / "common30", None, args, paths)
    common_checkpoint = Path(common["best_checkpoint"])
    runs = {}
    for index, variant in enumerate(VARIANTS, 1):
        print(f"\n[Experiment {index}/{len(VARIANTS)}] {variant}: {DISPLAY_NAMES[variant]}")
        runs[variant] = train_stage(f"{variant}_{args.branch_epochs}", variant,
            args.branch_epochs, args.output / f"branch_{variant}", common_checkpoint, args, paths)
        release_cuda()

    results = {"common": common, "training": runs, "final_evaluation": {}, "benchmark": {}}
    for index, variant in enumerate(VARIANTS, 1):
        checkpoint = Path(runs[variant]["best_checkpoint"])
        print(f"\n[Final evaluation {index}/{len(VARIANTS)}] {variant}")
        for split in ("val", "test"):
            results["final_evaluation"][f"{variant}_{split}"] = final_evaluate(
                variant, checkpoint, split, args, paths, args.output)
            release_cuda()
        if not args.skip_benchmark:
            results["benchmark"][variant] = benchmark(
                variant, checkpoint, args, paths, args.output)
            release_cuda()
    (args.output / "results.json").write_text(
        json.dumps(results, indent=2), encoding="utf-8")

    if not args.skip_analysis:
        run_all_analyses(args.output, paths, VARIANTS,
                         args.bootstrap_samples, args.branch_seed)
    from report import main as build_report
    build_report(args.output)
    (args.output / "ALL_COMPLETE.json").write_text(json.dumps({
        "status": "complete", "results": str(args.output / "results.json"),
        "report": str(args.output / "reports/summary.md")}, indent=2), encoding="utf-8")
    print("\n[ALL COMPLETE]")
    print("Report :", args.output / "reports/summary.md")
    print("Figures:", args.output / "reports/figures")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        print("\n[FATAL] The pipeline stopped safely. Re-run the same command after fixing the error; completed stages will be skipped.")
        traceback.print_exc()
        raise
