"""Evaluate a released baseline or LPI checkpoint on ExDark."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from pipeline import final_evaluate, validate_dataset


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--images", required=True, type=Path)
    parser.add_argument("--checkpoint", required=True, type=Path)
    parser.add_argument("--variant", choices=("baseline", "lpi"), default="lpi")
    parser.add_argument("--split", choices=("val", "test"), default="test")
    parser.add_argument("--output", type=Path, default=ROOT / "runs/released_eval")
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--workers", type=int, default=2)
    args = parser.parse_args()
    annotations = ROOT / "data/annotations"
    images = args.images.resolve()
    validate_dataset(images, annotations)
    paths = {"images": images, **{name: annotations / f"{name}.json" for name in ("train", "val", "test")}}
    runtime = SimpleNamespace(
        batch_size=args.batch_size,
        val_batch_size=args.batch_size,
        workers=args.workers,
        prefetch_factor=2,
        force_eval=True,
    )
    result = final_evaluate(
        args.variant,
        args.checkpoint.resolve(),
        args.split,
        runtime,
        paths,
        args.output.resolve(),
    )
    print(json.dumps(result["metrics"], indent=2))


if __name__ == "__main__":
    main()
