"""Fast repository check; no dataset or GPU is required."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = (
    "reproduce.py", "models.py", "pipeline.py", "analysis.py", "report.py",
    "weights.py", "configs/exdark.yml", "data/annotations/train.json",
    "data/annotations/val.json", "data/annotations/test.json",
    "assets/Multinex-Nano_LOL-v2-real.pth",
    "third_party/rtdetrv2/src/__init__.py",
    "third_party/multinex/MultinexNano_arch.py",
)


def digest(path: Path) -> str:
    value = hashlib.sha256(path.read_bytes()).hexdigest()
    return value


def main() -> None:
    missing = [name for name in REQUIRED if not (ROOT / name).is_file()]
    if missing:
        raise FileNotFoundError("missing repository files: " + ", ".join(missing))
    for path in ROOT.rglob("*.py"):
        if "third_party" not in path.parts:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    expected = {"train": 3000, "val": 1800, "test": 2563}
    for split, count in expected.items():
        data = json.loads((ROOT / f"data/annotations/{split}.json").read_text(encoding="utf-8"))
        if len(data["images"]) != count:
            raise ValueError(f"{split}: expected {count} images")
    nano = ROOT / "assets/Multinex-Nano_LOL-v2-real.pth"
    expected_nano = "444533ea24ce2a65266f314b5a6bcc0d52e01cf9fe962b292140d130739c5155"
    if digest(nano) != expected_nano:
        raise ValueError("Multinex-Nano checkpoint hash mismatch")
    print("[check] PASS: layout, Python syntax, annotations, and Nano checkpoint")


if __name__ == "__main__":
    main()

