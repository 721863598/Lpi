"""Download the COCO checkpoint used to initialize RT-DETRv2-R18."""
from __future__ import annotations

import argparse
import hashlib
import urllib.request
from pathlib import Path

URL = "https://github.com/lyuwenyu/storage/releases/download/v0.2/rtdetrv2_r18vd_120e_coco_rerun_48.1.pth"
SHA256 = "2ace52184b620204004509b72752ac7bfe64aadfa7fc1d076b18df8ab5a5c77e"
ROOT = Path(__file__).resolve().parents[1]


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "assets/rtdetrv2_r18_coco.pth")
    args = parser.parse_args()
    target = args.output.resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.is_file() and digest(target) == SHA256:
        print(f"[weights] ready: {target}")
        return
    temporary = target.with_suffix(target.suffix + ".part")
    print(f"[weights] downloading {URL}")
    urllib.request.urlretrieve(URL, temporary)
    actual = digest(temporary)
    if actual != SHA256:
        temporary.unlink(missing_ok=True)
        raise RuntimeError(f"checkpoint hash mismatch: {actual}")
    temporary.replace(target)
    print(f"[weights] saved: {target}")


if __name__ == "__main__":
    main()

