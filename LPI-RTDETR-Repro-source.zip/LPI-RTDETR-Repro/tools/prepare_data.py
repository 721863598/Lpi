"""Validate the fixed ExDark split without changing the dataset."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED = {"train": 3000, "val": 1800, "test": 2563}


def sha256(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--images", required=True, type=Path)
    parser.add_argument("--annotations", type=Path, default=ROOT / "data/annotations")
    args = parser.parse_args()
    images = args.images.resolve()
    annotations = args.annotations.resolve()
    seen: dict[str, set[str]] = {}
    categories = None
    for split, expected in EXPECTED.items():
        path = annotations / f"{split}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        if len(data["images"]) != expected:
            raise ValueError(f"{split}: expected {expected}, found {len(data['images'])}")
        current_categories = [(row["id"], row["name"]) for row in data["categories"]]
        if categories is None:
            categories = current_categories
        elif categories != current_categories:
            raise ValueError(f"{split}: category definitions differ")
        files = {row["file_name"].replace("\\", "/").lower() for row in data["images"]}
        missing = [row["file_name"] for row in data["images"] if not (images / row["file_name"]).is_file()]
        if missing:
            raise FileNotFoundError(f"{split}: {len(missing)} images missing; first: {missing[0]}")
        for other, other_files in seen.items():
            overlap = files & other_files
            if overlap:
                raise ValueError(f"{split}/{other}: {len(overlap)} overlapping files")
        seen[split] = files
        print(f"[data] {split}: {len(files)} images | {len(data['annotations'])} boxes | {sha256(path)[:12]}")
    if len(categories or []) != 12:
        raise ValueError(f"expected 12 categories, found {len(categories or [])}")
    print("[data] PASS: fixed split is complete and disjoint")


if __name__ == "__main__":
    main()

