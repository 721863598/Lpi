"""Strip optimizer state from a training checkpoint for GitHub Releases."""
from __future__ import annotations

import argparse
from pathlib import Path

import torch


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--variant", required=True)
    args = parser.parse_args()
    checkpoint = torch.load(args.source, map_location="cpu")
    state = checkpoint.get("ema", {}).get("module", checkpoint.get("model", checkpoint))
    compact = {
        "model": state,
        "ema": {"module": state, "updates": checkpoint.get("ema", {}).get("updates", 0)},
        "last_epoch": checkpoint.get("last_epoch", -1),
        "metadata": {
            "variant": args.variant,
            "input_size": [640, 640],
            "classes": 12,
            "dataset": "ExDark fixed split",
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    torch.save(compact, args.output)
    print(f"[export] {args.output} ({args.output.stat().st_size / 2**20:.1f} MiB)")


if __name__ == "__main__":
    main()

