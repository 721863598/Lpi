# Third-party components

## RT-DETRv2

The detector implementation under `third_party/rtdetrv2` comes from the
official RT-DETR repository: <https://github.com/lyuwenyu/RT-DETR>.
Local changes are limited to prediction export and step-level diagnostics used
by this experiment. Review the upstream repository terms before redistribution.

## Multinex

`third_party/multinex` contains the Multinex-Nano architecture. Its required
notice and PolyForm Noncommercial License are retained in that directory.
Commercial use requires separate permission from the original author.

