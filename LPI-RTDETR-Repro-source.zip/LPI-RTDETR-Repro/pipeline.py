import csv, gc, hashlib, json, os, platform, statistics, sys, time
from pathlib import Path
import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
RTDETR = ROOT / "third_party/rtdetrv2"
sys.path.insert(0, str(RTDETR))

from src.core import YAMLConfig
from src.misc import dist_utils
from src.solver import TASKS
from models import VARIANTS, build_model
from weights import initialize_coco, load_matching

CONFIG = ROOT / "configs/exdark.yml"
COCO_WEIGHT = ROOT / "assets/rtdetrv2_r18_coco.pth"
METRIC_NAMES = ("AP", "AP50", "AP75", "APS", "APM", "APL",
                "AR1", "AR10", "AR100", "ARS", "ARM", "ARL")


def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()


def resolve_images(data_root=None, images=None):
    candidates=[]
    if images: candidates.append(Path(images))
    if data_root:
        root=Path(data_root)
        candidates += [root,root/'images',root/'ExDark/images',root/'ExDark/ExDark/images']
    candidates += [ROOT/'data/images',ROOT/'ExDark/images']
    for path in candidates:
        if path.is_dir():
            # The official directory contains category subdirectories.
            if any(path.rglob('*.jpg')) or any(path.rglob('*.JPEG')):
                return path.resolve()
    raise FileNotFoundError("ExDark images not found; pass --data-root or --images")


def validate_dataset(images, annotations_dir):
    expected={'train':3000,'val':1800,'test':2563};manifest={'images_root':str(images),'splits':{}}
    categories=None;seen_files={};seen_ids={}
    for split,count in expected.items():
        path=annotations_dir/f'{split}.json';doc=json.loads(path.read_text(encoding='utf-8'))
        if len(doc['images'])!=count:raise ValueError(f'{split}: expected {count} images, got {len(doc["images"])}')
        cats=[(x['id'],x['name']) for x in doc['categories']]
        if categories is None:categories=cats
        elif categories!=cats:raise ValueError('category definitions differ across splits')
        missing=[x['file_name'] for x in doc['images'] if not (images/x['file_name']).is_file()]
        if missing:raise FileNotFoundError(f'{split}: {len(missing)} missing images; first={missing[0]}')
        files={x['file_name'].replace('\\','/').lower() for x in doc['images']}
        ids={int(x['id']) for x in doc['images']}
        for other,other_files in seen_files.items():
            overlap=files & other_files
            if overlap:raise ValueError(f'data leakage: {split}/{other} share {len(overlap)} files; first={next(iter(overlap))}')
        seen_files[split]=files;seen_ids[split]=ids
        class_counts={str(c[0]):0 for c in cats}
        for ann in doc['annotations']:class_counts[str(ann['category_id'])]+=1
        manifest['splits'][split]={'images':len(doc['images']),'annotations':len(doc['annotations']),
            'sha256':sha256(path),'file':str(path),'class_annotation_counts':class_counts}
    if len(categories)!=12:raise ValueError(f'expected 12 classes, got {len(categories)}')
    manifest['categories']=[{'id':i,'name':n} for i,n in categories]
    manifest['split_file_overlap_checked']=True
    return manifest


def configure_loaders(cfg, images, train_json, val_json, batch, val_batch, workers, prefetch):
    cfg.device='cuda';cfg.yaml_cfg['device']='cuda';cfg.print_freq=20;cfg.yaml_cfg['print_freq']=20
    cfg.checkpoint_freq=5;cfg.yaml_cfg['checkpoint_freq']=5
    train=cfg.yaml_cfg['train_dataloader'];val=cfg.yaml_cfg['val_dataloader']
    train['total_batch_size']=batch;val['total_batch_size']=val_batch
    train['dataset']['img_folder']=str(images);train['dataset']['ann_file']=str(train_json)
    val['dataset']['img_folder']=str(images);val['dataset']['ann_file']=str(val_json)
    for loader in (train,val):
        loader['num_workers']=workers;loader['pin_memory']=True;loader['persistent_workers']=workers>0
        if workers>0:loader['prefetch_factor']=prefetch
        else:loader.pop('prefetch_factor',None)


def build_cfg(epochs, output, images, train_json, val_json, batch, val_batch, workers, prefetch):
    cfg=YAMLConfig(str(CONFIG), epoches=epochs, output_dir=str(output))
    configure_loaders(cfg,images,train_json,val_json,batch,val_batch,workers,prefetch)
    return cfg


def configure_common30(cfg):
    cfg.yaml_cfg['optimizer']['lr']=1e-4
    cfg.yaml_cfg['lr_warmup_scheduler']['warmup_duration']=200
    cfg.yaml_cfg['lr_scheduler']['milestones']=[24];cfg.yaml_cfg['lr_scheduler']['gamma']=.1
    cfg.yaml_cfg['train_dataloader']['dataset']['transforms']['policy']['epoch']=27
    cfg.yaml_cfg['train_dataloader']['collate_fn']['stop_epoch']=27


def configure_branch80(cfg, kind):
    cfg.yaml_cfg['optimizer']['lr']=1e-5
    shared=[{'params':r'^backbone\.','lr':1e-6}, {'params':r'^(?:encoder|decoder)\.','lr':1e-5}]
    if kind!='baseline':
        cfg.yaml_cfg['optimizer']['params']=[
            {'params':r'^nano\.','lr':1e-4,'weight_decay':1e-5},
            {'params':r'^prior_fusion\.','lr':5e-4,'weight_decay':1e-5},*shared]
        if kind=='cascade':
            cfg.yaml_cfg['optimizer']['params']=[
                {'params':r'^(?:nano|blend_logit)','lr':1e-4,'weight_decay':1e-5},*shared]
    else:cfg.yaml_cfg['optimizer']['params']=shared
    cfg.yaml_cfg['lr_warmup_scheduler']['warmup_duration']=100
    cfg.yaml_cfg['lr_scheduler']['milestones']=[40,64,74];cfg.yaml_cfg['lr_scheduler']['gamma']=.2
    cfg.yaml_cfg['train_dataloader']['dataset']['transforms']['policy']['epoch']=68
    cfg.yaml_cfg['train_dataloader']['collate_fn']['stop_epoch']=68


def best_from_log(path):
    best=None
    if Path(path).exists():
        for line in Path(path).read_text(encoding='utf-8').splitlines():
            try:
                row=json.loads(line);score=float(row['test_coco_eval_bbox'][0])
                if best is None or score>best[0]:best=(score,int(row['epoch']),row)
            except (KeyError,ValueError,json.JSONDecodeError):pass
    return best or (-1.,-1,{})


def last_epoch_from_log(path):
    epochs=[]
    if Path(path).exists():
        for line in Path(path).read_text(encoding='utf-8').splitlines():
            try:epochs.append(int(json.loads(line)['epoch']))
            except (KeyError,ValueError,json.JSONDecodeError):pass
    return max(epochs,default=-1)


def train_stage(name, kind, epochs, output, source, args, paths):
    output.mkdir(parents=True,exist_ok=True);complete=output/'complete.json'
    if complete.exists():
        print(f'[Skip:{name}] complete');return json.loads(complete.read_text())
    cfg=build_cfg(epochs,output,paths['images'],paths['train'],paths['val'],
                  args.batch_size,args.val_batch_size,args.workers,args.prefetch_factor)
    if kind=='common':
        configure_common30(cfg);cfg.checkpoint_freq=10;cfg.yaml_cfg['checkpoint_freq']=10;model=cfg.model
        if (output/'last.pth').exists():cfg.resume=str(output/'last.pth')
        else:
            print('[Init:common]',initialize_coco(model,COCO_WEIGHT));cfg._model=model;cfg.resume=None
    else:
        configure_branch80(cfg,kind);cfg.checkpoint_freq=20;cfg.yaml_cfg['checkpoint_freq']=20;model=cfg.model
        model,criterion=build_model(model,cfg.criterion,kind)
        cfg._criterion=criterion
        cfg._model=model
        if (output/'last.pth').exists():cfg.resume=str(output/'last.pth')
        else:
            print(f'[Init:{name}]',load_matching(model,source));cfg.resume=None
    cfg.tuning=None
    # Reset immediately before solver construction so both branches see the
    # same sampler/augmentation RNG stream despite different model modules.
    dist_utils.setup_seed(args.seed if kind=='common' else args.branch_seed)
    print(f'[Start:{name}] epochs={epochs} batch={args.batch_size} workers={args.workers}')
    solver=TASKS[cfg.yaml_cfg['task']](cfg);solver.fit();del solver,cfg,model;gc.collect();torch.cuda.empty_cache()
    best=best_from_log(output/'log.txt')
    if last_epoch_from_log(output/'log.txt')+1 < epochs or not (output/'best.pth').exists():
        raise RuntimeError(f'{name} ended before epoch {epochs}; rerun the same command to resume')
    result={'name':name,'kind':kind,'epochs':epochs,'best_ap':best[0],'best_epoch':best[1],
            'best_checkpoint':str(output/'best.pth'),'source_checkpoint':str(source) if source else str(COCO_WEIGHT)}
    complete.write_text(json.dumps(result,indent=2),encoding='utf-8');return result


def build_eval_cfg(kind, checkpoint, output, split_json, args, paths):
    cfg=build_cfg(1,output,paths['images'],paths['train'],split_json,
                  args.batch_size,args.val_batch_size,args.workers,args.prefetch_factor)
    model=cfg.model
    model,criterion=build_model(model,cfg.criterion,kind)
    cfg._model=model;cfg._criterion=criterion;cfg.resume=str(checkpoint);cfg.tuning=None
    return cfg


def per_class_from_eval(eval_path, ann_path):
    ev=torch.load(eval_path,map_location='cpu');precision=np.asarray(ev['precision']);recall=np.asarray(ev['recall'])
    doc=json.loads(Path(ann_path).read_text(encoding='utf-8'));cats=sorted(doc['categories'],key=lambda x:x['id']);rows=[]
    for k,cat in enumerate(cats):
        def mean_valid(x):
            x=np.asarray(x);x=x[x>-1];return float(x.mean()) if x.size else float('nan')
        rows.append({'category_id':cat['id'],'category':cat['name'],
            'AP':mean_valid(precision[:,:,k,0,2]),'AP50':mean_valid(precision[0,:,k,0,2]),
            'AP75':mean_valid(precision[5,:,k,0,2]),'AR100':mean_valid(recall[:,k,0,2])})
    return rows


def final_evaluate(kind, checkpoint, split, args, paths, root):
    out=root/'final_eval'/kind/split;summary=out/'summary.json'
    if summary.exists() and not args.force_eval:return json.loads(summary.read_text())
    out.mkdir(parents=True,exist_ok=True);cfg=build_eval_cfg(kind,checkpoint,out,paths[split],args,paths)
    solver=TASKS[cfg.yaml_cfg['task']](cfg);solver.val();del solver,cfg;gc.collect();torch.cuda.empty_cache()
    raw=json.loads((out/'metrics.json').read_text());values=raw['coco_eval_bbox']
    result={'model':kind,'split':split,'checkpoint':str(checkpoint),
            'metrics':{name:float(value) for name,value in zip(METRIC_NAMES,values)},
            'per_class':per_class_from_eval(out/'eval.pth',paths[split])}
    summary.write_text(json.dumps(result,indent=2),encoding='utf-8');return result


def _conv_linear_macs(model,x):
    total=[0];hooks=[]
    def conv(m,inp,out):
        total[0]+=out.numel()*(m.in_channels//m.groups)*m.kernel_size[0]*m.kernel_size[1]
    def linear(m,inp,out):total[0]+=out.numel()*m.in_features
    for module in model.modules():
        if isinstance(module,torch.nn.Conv2d):hooks.append(module.register_forward_hook(conv))
        elif isinstance(module,torch.nn.Linear):hooks.append(module.register_forward_hook(linear))
    with torch.inference_mode():model(x)
    for hook in hooks:hook.remove()
    return total[0]


def benchmark(kind,checkpoint,args,paths,root):
    path=root/'benchmark'/f'{kind}.json'
    if path.exists() and not args.force_benchmark:return json.loads(path.read_text())
    path.parent.mkdir(parents=True,exist_ok=True)
    cfg=build_cfg(1,path.parent,paths['images'],paths['train'],paths['val'],args.batch_size,args.val_batch_size,0,2)
    model=cfg.model
    model,_=build_model(model,cfg.criterion,kind)
    info=load_matching(model,checkpoint);model=model.cuda().eval();x=torch.rand(1,3,640,640,device='cuda')
    macs=_conv_linear_macs(model,x)
    def timing(amp):
        for _ in range(args.benchmark_warmup):
            with torch.inference_mode(),torch.autocast('cuda',enabled=amp):model(x)
        torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();times=[]
        for _ in range(args.benchmark_iters):
            start=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True);start.record()
            with torch.inference_mode(),torch.autocast('cuda',enabled=amp):model(x)
            end.record();torch.cuda.synchronize();times.append(start.elapsed_time(end))
        return {'mean_ms':statistics.mean(times),'median_ms':statistics.median(times),
                'p90_ms':float(np.percentile(times,90)),'fps':1000./statistics.mean(times),
                'peak_memory_mb':torch.cuda.max_memory_allocated()/2**20}
    total_params=sum(p.numel() for p in model.parameters());state_mb=sum(v.numel()*v.element_size() for v in model.state_dict().values())/2**20
    result={'model':kind,'checkpoint':str(checkpoint),'load_info':info,'input':[1,3,640,640],
      'parameters':total_params,'parameters_M':total_params/1e6,'state_dict_mb':state_mb,
      'conv_linear_MACs_G':macs/1e9,'conv_linear_approx_GFLOPs':2*macs/1e9,
      'fp32':timing(False),'amp_fp16':timing(True),'postprocessing_included':False,
      'hardware':torch.cuda.get_device_name(0),'torch':torch.__version__,'cuda':torch.version.cuda}
    path.write_text(json.dumps(result,indent=2),encoding='utf-8');del model,cfg,x;gc.collect();torch.cuda.empty_cache();return result


def environment_manifest(args,dataset):
    gpu=torch.cuda.get_device_name(0) if torch.cuda.is_available() else None
    props=torch.cuda.get_device_properties(0) if torch.cuda.is_available() else None
    return {'created':time.strftime('%Y-%m-%d %H:%M:%S'),'platform':platform.platform(),'python':sys.version,
      'torch':torch.__version__,'torchvision':__import__('torchvision').__version__,'cuda':torch.version.cuda,
      'cudnn':torch.backends.cudnn.version(),'gpu':gpu,'gpu_count':torch.cuda.device_count(),
      'gpu_total_memory_gb':props.total_memory/2**30 if props else None,
      'cpu_count':os.cpu_count(),'seed':args.seed,'branch_seed':args.branch_seed,
      'batch_size':args.batch_size,'val_batch_size':args.val_batch_size,'workers':args.workers,
      'coco_checkpoint_sha256':sha256(COCO_WEIGHT),'dataset':dataset}

