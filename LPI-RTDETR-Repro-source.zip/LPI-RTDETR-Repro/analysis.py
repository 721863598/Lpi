"""Post-training analyses that operate only on saved COCO predictions."""
from __future__ import annotations

import contextlib
import copy
import io
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval

METRICS = ("AP", "AP50", "AP75", "APS", "APM", "APL",
           "AR1", "AR10", "AR100", "ARS", "ARM", "ARL")


def _silent_eval(coco_gt, predictions, img_ids=None, cat_ids=None):
    with contextlib.redirect_stdout(io.StringIO()):
        coco_dt = coco_gt.loadRes(predictions) if predictions else coco_gt.loadRes([])
        ev = COCOeval(coco_gt, coco_dt, "bbox")
        if img_ids is not None:
            ev.params.imgIds = [int(x) for x in img_ids]
        if cat_ids is not None:
            ev.params.catIds = [int(x) for x in cat_ids]
        ev.evaluate(); ev.accumulate(); ev.summarize()
    return np.asarray(ev.stats, dtype=float)


def _image_luminance(path):
    with Image.open(path) as image:
        image.thumbnail((256, 256))
        rgb = np.asarray(image.convert("RGB"), dtype=np.float32) / 255.
    return float((.299 * rgb[..., 0] + .587 * rgb[..., 1] + .114 * rgb[..., 2]).mean())


def build_luminance_manifest(images_root, annotation_paths, output):
    output = Path(output)
    if output.exists():
        return pd.read_csv(output)
    rows = []
    for split, ann_path in annotation_paths.items():
        doc = json.loads(Path(ann_path).read_text(encoding="utf-8"))
        for index, image in enumerate(doc["images"], 1):
            rows.append({"split": split, "image_id": int(image["id"]),
                         "file_name": image["file_name"],
                         "mean_luminance": _image_luminance(Path(images_root) / image["file_name"])})
            if index % 500 == 0:
                print(f"[Analysis:luminance] {split} {index}/{len(doc['images'])}")
    frame = pd.DataFrame(rows)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output, index=False)
    return frame


def brightness_analysis(root, images_root, paths, variants):
    out = Path(root) / "analysis"
    out.mkdir(parents=True, exist_ok=True)
    lum = build_luminance_manifest(images_root,
        {s: paths[s] for s in ("train", "val", "test")}, out / "luminance_manifest.csv")
    thresholds = np.quantile(lum.loc[lum.split == "train", "mean_luminance"], [.25, .5, .75])
    labels = ("Q1_extreme_dark", "Q2_dark", "Q3_mid", "Q4_brighter")
    lum["brightness_bin"] = pd.cut(lum.mean_luminance,
        bins=[-np.inf, *thresholds.tolist(), np.inf], labels=labels, include_lowest=True)
    lum.to_csv(out / "luminance_manifest.csv", index=False)
    (out / "brightness_thresholds.json").write_text(json.dumps({
        "source": "train-set mean RGB luminance quartiles",
        "q25_q50_q75": thresholds.tolist(), "labels": labels}, indent=2), encoding="utf-8")

    doc = json.loads(Path(paths["test"]).read_text(encoding="utf-8"))
    categories = sorted(doc["categories"], key=lambda x: x["id"])
    with contextlib.redirect_stdout(io.StringIO()):
        coco = COCO(str(paths["test"]))
    test_lum = lum[lum.split == "test"]
    metric_rows, class_rows, size_rows = [], [], []
    for variant in variants:
        prediction_path = Path(root) / "final_eval" / variant / "test" / "predictions.json"
        predictions = json.loads(prediction_path.read_text(encoding="utf-8"))
        for label in labels:
            ids = test_lum.loc[test_lum.brightness_bin == label, "image_id"].astype(int).tolist()
            stats = _silent_eval(coco, predictions, ids)
            metric_rows.append({"model": variant, "brightness_bin": label, "images": len(ids),
                                **{name: stats[i] for i, name in enumerate(METRICS)}})
            for category in categories:
                class_stats = _silent_eval(coco, predictions, ids, [category["id"]])
                class_rows.append({"model": variant, "brightness_bin": label,
                    "category_id": category["id"], "category": category["name"],
                    "AP": class_stats[0], "AP50": class_stats[1], "AP75": class_stats[2]})
            for index, size in enumerate(("small", "medium", "large"), 3):
                size_rows.append({"model": variant, "brightness_bin": label,
                                  "size": size, "AP": stats[index]})
        print(f"[Analysis:brightness] {variant} complete")
    pd.DataFrame(metric_rows).to_csv(out / "metrics_by_brightness.csv", index=False)
    pd.DataFrame(class_rows).to_csv(out / "class_by_brightness.csv", index=False)
    pd.DataFrame(size_rows).to_csv(out / "size_by_brightness.csv", index=False)


def _top_predictions(predictions, max_dets=100):
    grouped = defaultdict(list)
    for row in predictions:
        grouped[int(row["image_id"])].append(row)
    return {key: sorted(rows, key=lambda x: x["score"], reverse=True)[:max_dets]
            for key, rows in grouped.items()}


def _bootstrap_dataset(base_doc, sampled_ids, annotations_by_image, predictions_by_image):
    sampled = {"images": [], "annotations": [], "categories": copy.deepcopy(base_doc["categories"])}
    result, ann_id = [], 1
    image_lookup = {int(x["id"]): x for x in base_doc["images"]}
    for new_id, old_id in enumerate(sampled_ids, 1):
        image = copy.deepcopy(image_lookup[int(old_id)]); image["id"] = new_id
        sampled["images"].append(image)
        for old_ann in annotations_by_image[int(old_id)]:
            ann = copy.deepcopy(old_ann); ann["id"] = ann_id; ann["image_id"] = new_id
            sampled["annotations"].append(ann); ann_id += 1
        for old_pred in predictions_by_image.get(int(old_id), []):
            pred = dict(old_pred); pred["image_id"] = new_id; result.append(pred)
    return sampled, result


def paired_bootstrap(root, test_json, baseline="baseline", candidate="lpi", samples=200, seed=2027):
    out = Path(root) / "analysis"
    out.mkdir(parents=True, exist_ok=True)
    target = out / "paired_bootstrap.csv"
    if target.exists() and len(pd.read_csv(target)) >= samples:
        print("[Analysis:bootstrap] cached"); return
    doc = json.loads(Path(test_json).read_text(encoding="utf-8"))
    ids = np.asarray([int(x["id"]) for x in doc["images"]], dtype=int)
    annotations = defaultdict(list)
    for ann in doc["annotations"]:
        annotations[int(ann["image_id"])].append(ann)
    grouped = {}
    for model in (baseline, candidate):
        predictions = json.loads((Path(root) / "final_eval" / model / "test" / "predictions.json").read_text(encoding="utf-8"))
        # Keep all decoder queries. COCO applies maxDets after grouping by
        # image and category, so a global top-100 truncation changes AP.
        grouped[model] = _top_predictions(predictions, max_dets=300)
    rng = np.random.default_rng(seed); rows = []
    for index in range(samples):
        sampled_ids = rng.choice(ids, size=len(ids), replace=True)
        stats = {}
        for model in (baseline, candidate):
            sampled_doc, sampled_predictions = _bootstrap_dataset(doc, sampled_ids, annotations, grouped[model])
            with contextlib.redirect_stdout(io.StringIO()):
                coco = COCO(); coco.dataset = sampled_doc; coco.createIndex()
            stats[model] = _silent_eval(coco, sampled_predictions)
        rows.append({"replicate": index,
            **{f"delta_{name}": stats[candidate][i] - stats[baseline][i]
               for i, name in enumerate(("AP", "AP50", "AP75", "APS"))}})
        if (index + 1) % 20 == 0:
            pd.DataFrame(rows).to_csv(target, index=False)
            print(f"[Analysis:bootstrap] {index + 1}/{samples}")
    frame = pd.DataFrame(rows); frame.to_csv(target, index=False)
    summary = {}
    for name in ("AP", "AP50", "AP75", "APS"):
        values = frame[f"delta_{name}"].to_numpy()
        summary[name] = {"mean_delta": float(values.mean()),
                         "ci95_low": float(np.quantile(values, .025)),
                         "ci95_high": float(np.quantile(values, .975)),
                         "probability_positive": float((values > 0).mean())}
    (out / "paired_bootstrap_summary.json").write_text(json.dumps({
        "unit": "image", "paired": True, "replicates": samples,
        "seed": seed, "candidate_minus_baseline": summary}, indent=2), encoding="utf-8")


def _iou_matrix(a, b):
    if not len(a) or not len(b): return np.zeros((len(a), len(b)), dtype=float)
    a = np.asarray(a, float); b = np.asarray(b, float)
    ax2, ay2 = a[:, 0] + a[:, 2], a[:, 1] + a[:, 3]
    bx2, by2 = b[:, 0] + b[:, 2], b[:, 1] + b[:, 3]
    ix1 = np.maximum(a[:, None, 0], b[None, :, 0]); iy1 = np.maximum(a[:, None, 1], b[None, :, 1])
    ix2 = np.minimum(ax2[:, None], bx2[None, :]); iy2 = np.minimum(ay2[:, None], by2[None, :])
    inter = np.maximum(ix2 - ix1, 0) * np.maximum(iy2 - iy1, 0)
    area_a = a[:, 2, None] * a[:, 3, None]
    area_b = b[None, :, 2] * b[None, :, 3]
    return inter / np.maximum(area_a + area_b - inter, 1e-9)


def confusion_analysis(root, test_json, variants, score_threshold=.25, iou_threshold=.5):
    out = Path(root) / "analysis"; doc = json.loads(Path(test_json).read_text(encoding="utf-8"))
    categories = sorted(doc["categories"], key=lambda x: x["id"]); n = len(categories)
    gt = defaultdict(list)
    for ann in doc["annotations"]: gt[int(ann["image_id"])].append(ann)
    for model in variants:
        predictions = json.loads((Path(root) / "final_eval" / model / "test" / "predictions.json").read_text(encoding="utf-8"))
        pred = _top_predictions([x for x in predictions if x["score"] >= score_threshold])
        matrix = np.zeros((n + 1, n + 1), dtype=int)
        for image in doc["images"]:
            image_id = int(image["id"]); g = gt[image_id]; p = pred.get(image_id, [])
            order = sorted(range(len(p)), key=lambda j: p[j]["score"], reverse=True)
            used = set(); ious = _iou_matrix([x["bbox"] for x in g], [x["bbox"] for x in p])
            for j in order:
                candidates = [(ious[i, j], i) for i in range(len(g)) if i not in used]
                best_iou, best_i = max(candidates, default=(0., -1))
                predicted = int(p[j]["category_id"])
                if best_iou >= iou_threshold:
                    matrix[int(g[best_i]["category_id"]), predicted] += 1; used.add(best_i)
                else: matrix[n, predicted] += 1
            for i, item in enumerate(g):
                if i not in used: matrix[int(item["category_id"]), n] += 1
        names = [x["name"] for x in categories] + ["background"]
        pd.DataFrame(matrix, index=names, columns=names).to_csv(out / f"confusion_{model}.csv")
    (out / "confusion_protocol.json").write_text(json.dumps({
        "score_threshold": score_threshold, "iou_threshold": iou_threshold,
        "rows": "ground truth", "columns": "prediction"}, indent=2), encoding="utf-8")


def run_all_analyses(root, paths, variants, bootstrap_samples=200, seed=2027):
    brightness_analysis(root, paths["images"], paths, variants)
    paired_bootstrap(root, paths["test"], "baseline", "lpi", bootstrap_samples, seed)
    confusion_analysis(root, paths["test"], variants)
    print("[Analysis] all post-training analyses complete")
