# GitHub upload

The repository has already been initialized with the `main` branch. Review the
files, add your own repository URL, then run:

```bash
git add .
git commit -m "Release ExDark reproduction code"
git remote add origin https://github.com/USER/LPI-RTDETR.git
git push -u origin main
```

The two `.pth` files under `release_assets` are intentionally ignored. Upload
them separately from the GitHub Releases page, or use the command in
`release_assets/README.md`. Do not force-add the checkpoints to the Git history.
