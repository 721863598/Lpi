"""Build tables and diagnostic plots from saved experiment outputs."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "third_party/rtdetrv2"))
from models import DISPLAY_NAMES, VARIANTS

METRICS = ("AP", "AP50", "AP75", "APS", "APM", "APL",
           "AR1", "AR10", "AR100", "ARS", "ARM", "ARL")
COLORS = {"baseline": "#3977af", "cascade": "#888888", "lpi": "#16a39a",
          "gated": "#e59a35", "regularized": "#d34e4e"}


def read_jsonl(path):
    rows = []
    if Path(path).exists():
        for line in Path(path).read_text(encoding="utf-8").splitlines():
            try: rows.append(json.loads(line))
            except json.JSONDecodeError: pass
    return pd.DataFrame(rows)


def epoch_metrics(path):
    rows = []
    for row in read_jsonl(path).to_dict("records"):
        values = row.get("test_coco_eval_bbox")
        if values:
            rows.append({"epoch": int(row["epoch"]) + 1,
                         **{name: 100 * float(values[i]) for i, name in enumerate(METRICS)}})
    return pd.DataFrame(rows)


def savefig(fig, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout(); fig.savefig(path.with_suffix(".png"), dpi=300, bbox_inches="tight")
    fig.savefig(path.with_suffix(".pdf"), bbox_inches="tight"); plt.close(fig)


def heatmap(frame, title, path, fmt=".2f", cmap="viridis", centered=False):
    values = frame.to_numpy(dtype=float)
    fig, ax = plt.subplots(figsize=(max(7, .72 * frame.shape[1] + 3), max(4, .5 * frame.shape[0] + 2)))
    if centered:
        bound = max(abs(np.nanmin(values)), abs(np.nanmax(values)), 1e-6)
        image = ax.imshow(values, cmap=cmap, aspect="auto", vmin=-bound, vmax=bound)
    else: image = ax.imshow(values, cmap=cmap, aspect="auto")
    ax.set_xticks(range(frame.shape[1]), frame.columns, rotation=35, ha="right")
    ax.set_yticks(range(frame.shape[0]), frame.index)
    threshold = np.nanmean(values)
    for i in range(frame.shape[0]):
        for j in range(frame.shape[1]):
            value = values[i, j]
            if np.isfinite(value):
                ax.text(j, i, format(value, fmt), ha="center", va="center", fontsize=7,
                        color="white" if centered or value > threshold else "black")
    ax.set_title(title); fig.colorbar(image, ax=ax, fraction=.025, pad=.02); savefig(fig, path)


def collect_results(root):
    evals, benches = {}, {}
    for model in VARIANTS:
        for split in ("val", "test"):
            path = root / "final_eval" / model / split / "summary.json"
            if path.exists(): evals[(model, split)] = json.loads(path.read_text(encoding="utf-8"))
        path = root / "benchmark" / f"{model}.json"
        if path.exists(): benches[model] = json.loads(path.read_text(encoding="utf-8"))
    return evals, benches


def training_figures(root, figures):
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.4))
    for model in VARIANTS:
        frame = epoch_metrics(root / f"branch_{model}" / "log.txt")
        if frame.empty: continue
        for ax, metric in zip(axes, ("AP", "AP50", "AP75")):
            ax.plot(frame.epoch, frame[metric], label=DISPLAY_NAMES[model], color=COLORS[model], lw=1.6)
            ax.set_title(f"Validation {metric}"); ax.set_xlabel("Continuation epoch"); ax.set_ylabel("%"); ax.grid(alpha=.25)
    axes[0].legend(fontsize=7); savefig(fig, figures / "validation_curves_all_models")

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.4))
    for model in ("baseline", "lpi"):
        frame = read_jsonl(root / f"branch_{model}" / "train_steps.jsonl")
        if frame.empty: continue
        for ax, key, title in zip(axes, ("loss_total", "loss_vfl", "loss_bbox"),
                                  ("Total loss", "Varifocal loss", "Box L1 loss")):
            if key not in frame: continue
            ax.plot(frame.global_step, frame[key], color=COLORS[model], alpha=.08, lw=.4)
            ax.plot(frame.global_step, frame[key].rolling(100, min_periods=1).mean(),
                    color=COLORS[model], lw=1.6, label=DISPLAY_NAMES[model])
            ax.set_title(title); ax.set_xlabel("Optimizer step"); ax.grid(alpha=.25)
    axes[0].legend(fontsize=8); savefig(fig, figures / "training_loss_raw_and_smoothed")

    frame = read_jsonl(root / "branch_lpi" / "train_steps.jsonl")
    if not frame.empty and "fusion_scale_p3" in frame:
        fig, axes = plt.subplots(1, 3, figsize=(15, 4.2))
        for level in ("p3", "p4", "p5"):
            axes[0].plot(frame.global_step, frame[f"fusion_scale_{level}"].rolling(50, min_periods=1).mean(), label=level.upper())
            axes[1].plot(frame.global_step, 100 * frame[f"injection_ratio_{level}"].rolling(50, min_periods=1).mean(), label=level.upper())
            axes[2].plot(frame.global_step, frame[f"gate_mean_{level}"].rolling(50, min_periods=1).mean(), label=level.upper())
        for ax, title, ylabel in zip(axes, ("Learned residual scale", "Feature injection ratio", "Gate activation"),
                                     ("Scale", "% feature magnitude", "Mean gate")):
            ax.set_title(title); ax.set_xlabel("Optimizer step"); ax.set_ylabel(ylabel); ax.grid(alpha=.25); ax.legend()
        savefig(fig, figures / "lpi_internal_diagnostics")


def result_tables(reports, evals, benches):
    rows, per_class = [], []
    for model in VARIANTS:
        for split in ("val", "test"):
            if (model, split) not in evals: continue
            metric = evals[(model, split)]["metrics"]; bench = benches.get(model, {})
            rows.append({"Model": DISPLAY_NAMES[model], "Key": model, "Split": split,
                **{name: 100 * metric[name] for name in ("AP", "AP50", "AP75", "APS", "APM", "APL", "AR100")},
                "Params(M)": bench.get("parameters_M"), "MACs(G)": bench.get("conv_linear_MACs_G"),
                "FP16 latency(ms)": bench.get("amp_fp16", {}).get("mean_ms"),
                "FP16 FPS": bench.get("amp_fp16", {}).get("fps"),
                "Peak VRAM(MB)": bench.get("amp_fp16", {}).get("peak_memory_mb")})
            for item in evals[(model, split)]["per_class"]:
                per_class.append({"model": model, "Model": DISPLAY_NAMES[model], "split": split,
                    **{k: (100 * v if k in ("AP", "AP50", "AP75", "AR100") else v) for k, v in item.items()}})
    table = pd.DataFrame(rows); classes = pd.DataFrame(per_class)
    table.to_csv(reports / "same_protocol_comparison.csv", index=False, float_format="%.5f")
    classes.to_csv(reports / "per_class_metrics.csv", index=False, float_format="%.5f")
    if not table.empty:
        (reports / "same_protocol_comparison.md").write_text(table.to_markdown(index=False, floatfmt=".3f"), encoding="utf-8")
        (reports / "same_protocol_comparison.tex").write_text(table.to_latex(index=False, float_format="%.3f"), encoding="utf-8")
    if not classes.empty:
        classes[classes.split == "test"].pivot(index="Model", columns="category", values="AP").to_csv(reports / "test_per_class_AP_matrix.csv")
    return table, classes


def result_figures(root, figures, table, classes):
    test = table[table.Split == "test"].set_index("Key") if not table.empty else pd.DataFrame()
    if not test.empty:
        metrics = ("AP", "AP50", "AP75", "APS", "APM", "APL", "AR100")
        fig, ax = plt.subplots(figsize=(11, 5)); x = np.arange(len(metrics)); width = .15
        for index, model in enumerate(VARIANTS):
            if model in test.index:
                ax.bar(x + (index - 2) * width, [test.loc[model, k] for k in metrics], width,
                       label=DISPLAY_NAMES[model], color=COLORS[model])
        ax.set_xticks(x, metrics); ax.set_ylabel("%"); ax.set_title("ExDark test: controlled ablation")
        ax.grid(axis="y", alpha=.25); ax.legend(fontsize=7, ncol=2); savefig(fig, figures / "test_ablation_metrics")
        if all(x in test.index for x in ("baseline", "lpi")):
            delta = pd.Series({metric: test.loc["lpi", metric] - test.loc["baseline", metric] for metric in metrics})
            delta.to_csv(root / "reports" / "lpi_minus_baseline.csv", header=["percentage_point_delta"])
            fig, ax = plt.subplots(figsize=(9, 4.5)); colors = ["#4a9d63" if x >= 0 else "#c94a4a" for x in delta]
            ax.bar(delta.index, delta.values, color=colors); ax.axhline(0, color="black", lw=.8)
            ax.set_ylabel("Percentage-point change"); ax.set_title("LPI-RTDETR minus RT-DETRv2 baseline")
            ax.grid(axis="y", alpha=.25); savefig(fig, figures / "lpi_metric_gains")
        if test["FP16 FPS"].notna().any():
            fig, ax = plt.subplots(figsize=(7, 5))
            for model, row in test.iterrows():
                ax.scatter(row["FP16 FPS"], row.AP, s=75, color=COLORS[model]); ax.annotate(model, (row["FP16 FPS"], row.AP), xytext=(5, 4), textcoords="offset points")
            ax.set_xlabel("FP16 FPS (batch 1)"); ax.set_ylabel("COCO AP (%)"); ax.grid(alpha=.25)
            ax.set_title("Accuracy–speed trade-off on the same GPU"); savefig(fig, figures / "accuracy_speed")
    if not classes.empty:
        test_class = classes[classes.split == "test"]
        matrix = test_class.pivot(index="Model", columns="category", values="AP")
        heatmap(matrix, "Per-class COCO AP (%)", figures / "per_class_AP_heatmap")
        by_key = test_class.pivot(index="model", columns="category", values="AP")
        if "baseline" in by_key.index and "lpi" in by_key.index:
            gain = pd.DataFrame([by_key.loc["lpi"] - by_key.loc["baseline"]], index=["LPI − baseline"])
            heatmap(gain, "Per-class AP change (percentage points)", figures / "per_class_gain_heatmap", cmap="RdBu_r", centered=True)
    fig, ax = plt.subplots(figsize=(7, 5.5)); plotted = False
    for model in VARIANTS:
        path = root / "final_eval" / model / "test" / "eval.pth"
        if not path.exists(): continue
        raw = torch.load(path, map_location="cpu"); precision = np.asarray(raw["precision"])[:, :, :, 0, 2]
        precision[precision < 0] = np.nan; curve = np.nanmean(precision, axis=(0, 2))
        ax.plot(np.linspace(0, 1, len(curve)), curve, label=DISPLAY_NAMES[model], color=COLORS[model]); plotted = True
    if plotted:
        ax.set_xlabel("Recall"); ax.set_ylabel("Precision"); ax.set_xlim(0, 1); ax.set_ylim(0, 1)
        ax.grid(alpha=.25); ax.legend(fontsize=7); ax.set_title("Mean precision–recall curves (IoU 0.50:0.95)")
        savefig(fig, figures / "precision_recall_curves")
    else: plt.close(fig)


def analysis_figures(root, figures):
    analysis = root / "analysis"; path = analysis / "metrics_by_brightness.csv"
    if path.exists():
        frame = pd.read_csv(path); matrix = frame.pivot(index="model", columns="brightness_bin", values="AP") * 100
        matrix.index = [DISPLAY_NAMES.get(x, x) for x in matrix.index]
        heatmap(matrix, "COCO AP by test-image brightness (%)", figures / "brightness_AP_heatmap")
    path = analysis / "class_by_brightness.csv"
    if path.exists():
        frame = pd.read_csv(path); base = frame[frame.model == "baseline"].pivot(index="brightness_bin", columns="category", values="AP")
        lpi = frame[frame.model == "lpi"].pivot(index="brightness_bin", columns="category", values="AP")
        heatmap((lpi - base) * 100, "LPI − baseline AP by class and brightness (pp)", figures / "class_brightness_gain", cmap="RdBu_r", centered=True)
    path = analysis / "size_by_brightness.csv"
    if path.exists():
        frame = pd.read_csv(path); base = frame[frame.model == "baseline"].pivot(index="brightness_bin", columns="size", values="AP")
        lpi = frame[frame.model == "lpi"].pivot(index="brightness_bin", columns="size", values="AP")
        heatmap((lpi - base) * 100, "LPI − baseline AP by size and brightness (pp)", figures / "size_brightness_gain", cmap="RdBu_r", centered=True)
    for model in ("baseline", "lpi"):
        path = analysis / f"confusion_{model}.csv"
        if path.exists():
            matrix = pd.read_csv(path, index_col=0).astype(float)
            normalized = matrix.div(matrix.sum(axis=1).replace(0, 1), axis=0) * 100
            heatmap(normalized, f"Normalized confusion matrix: {DISPLAY_NAMES[model]} (%)", figures / f"confusion_{model}", fmt=".1f", cmap="Blues")
    path = analysis / "paired_bootstrap_summary.json"
    if path.exists():
        data = json.loads(path.read_text())["candidate_minus_baseline"]
        names = list(data); means = np.array([100 * data[x]["mean_delta"] for x in names])
        low = np.array([100 * data[x]["ci95_low"] for x in names]); high = np.array([100 * data[x]["ci95_high"] for x in names])
        fig, ax = plt.subplots(figsize=(7, 4)); y = np.arange(len(names))
        ax.errorbar(means, y, xerr=[means-low, high-means], fmt="o", color="#d34e4e", capsize=5)
        ax.axvline(0, color="black", lw=.8); ax.set_yticks(y, names); ax.set_xlabel("LPI − baseline (percentage points)")
        ax.set_title("Paired image bootstrap, 95% confidence intervals"); ax.grid(axis="x", alpha=.25)
        savefig(fig, figures / "bootstrap_confidence_intervals")


def main(root=None):
    root = Path(root or Path(__file__).resolve().parent / "runs/exdark").resolve()
    reports = root / "reports"; figures = reports / "figures"
    reports.mkdir(parents=True, exist_ok=True); figures.mkdir(parents=True, exist_ok=True)
    evals, benches = collect_results(root); training_figures(root, figures)
    table, classes = result_tables(reports, evals, benches)
    result_figures(root, figures, table, classes); analysis_figures(root, figures)
    lines = ["# ExDark experiment summary", "", "## Protocol", "",
        "- Fixed split: 3000 training / 1800 validation / 2563 test images; 12 categories.",
        "- RT-DETRv2-R18, 640×640; single-scale inference without TTA.",
        "- All rows start from the identical common checkpoint and use identical data order, augmentation and epoch budget.",
        "- Validation COCO AP selects checkpoints. Test is evaluated only after selection.",
        "- Primary metric: COCO AP@[0.50:0.95]. AP50 is retained for ExDark literature context.",
        "", "## Controlled results", ""]
    md = reports / "same_protocol_comparison.md"
    if md.exists(): lines.append(md.read_text(encoding="utf-8"))
    lines += ["", "## Interpretation rules", "",
        "The pixel-cascade row is a control. LPI, gated and regularized rows form the ablation sequence.",
        "", "## Statistical analysis", "",
        "Paired bootstrap resamples test images and reports candidate-minus-baseline uncertainty; it is not a substitute for multi-seed training.",
        "", "## Efficiency protocol", "",
        "Latency is batch-1 CUDA model latency after warm-up; preprocessing and postprocessing are excluded.",
        "", "## Retained artifacts", "",
        "Step logs, epoch metrics, predictions, evaluator tensors, brightness strata, confusion matrices, bootstrap replicates, CSV/Markdown/LaTeX tables, PNG and PDF figures are retained."]
    (reports / "summary.md").write_text("\n".join(lines), encoding="utf-8")
    print(f"[Report] {reports}")


if __name__ == "__main__": main()
